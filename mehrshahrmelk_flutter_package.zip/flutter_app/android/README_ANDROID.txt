Place your android google-services.json here:
- android/app/google-services.json
Then follow FlutterFire docs to configure Android.
