Place your iOS GoogleService-Info.plist here:
- ios/Runner/GoogleService-Info.plist
Then follow FlutterFire docs to configure iOS.
